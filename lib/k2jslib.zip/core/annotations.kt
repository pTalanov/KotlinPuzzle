package js;

native
annotation class native(name : String = "") {}
native
annotation class library(name : String = "") {}